// Shared atoms
const { useEffect, useRef, useState, useMemo } = React;

function Icon({ name, className = "", size = 16, strokeWidth = 1.5 }) {
  const ref = useRef(null);
  useEffect(() => {
    if (window.lucide && ref.current) {
      ref.current.innerHTML = "";
      const el = document.createElement("i");
      el.setAttribute("data-lucide", name);
      ref.current.appendChild(el);
      window.lucide.createIcons({
        attrs: { width: size, height: size, "stroke-width": strokeWidth, class: className },
        nameAttr: "data-lucide",
      });
    }
  }, [name, size, strokeWidth, className]);
  return <span ref={ref} aria-hidden="true" className="inline-flex items-center justify-center" style={{ width: size, height: size }} />;
}

function Reveal({ children, as: As = "div", className = "", delay = 0, y = 18 }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty("--ry", `${y}px`);
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          setTimeout(() => el.classList.add("in"), delay);
          io.unobserve(el);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [delay, y]);
  return <As ref={ref} className={`reveal ${className}`}>{children}</As>;
}

// Word-by-word reveal for editorial headlines
function WordReveal({ text, className = "", delay = 0, stagger = 60 }) {
  const words = text.split(" ");
  return (
    <span className={className}>
      {words.map((w, i) => (
        <span key={i} className="word-reveal" style={{ animationDelay: `${delay + i * stagger}ms` }}>
          {w}{i < words.length - 1 ? "\u00A0" : ""}
        </span>
      ))}
    </span>
  );
}

function Eyebrow({ children, className = "" }) {
  return (
    <div className={`eyebrow inline-flex items-center gap-3 ${className}`}>
      <span className="inline-block h-px w-8 bg-[var(--text)]" />
      <span>{children}</span>
    </div>
  );
}

Object.assign(window, { Icon, Reveal, WordReveal, Eyebrow });
