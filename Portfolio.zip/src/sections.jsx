// Sections: About, Stack, Work, Experience, Footer
const { useEffect: useEffectS, useState: useStateS, useRef: useRefS } = React;

function About({ t, lang }) {
  return (
    <section id="about" className="relative py-24 md:py-36 overflow-hidden">
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-5">
            <Reveal><Eyebrow>{t.about.eyebrow}</Eyebrow></Reveal>
            <Reveal delay={80}>
              <h2 className="mt-6 font-display font-medium tracking-[-0.025em] text-[var(--text)] text-[34px] md:text-[52px] xl:text-[60px] leading-[1.02]">
                {t.about.title}
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-7 lg:pt-3">
            <Reveal delay={140}>
              <div className="space-y-5 text-[15.5px] md:text-[17px] text-[var(--muted)] leading-[1.7] max-w-2xl">
                {t.about.body.map((p, i) => (
                  <p key={i} className={i === 0 ? "first-letter-display" : ""}>{p}</p>
                ))}
              </div>
            </Reveal>
            <Reveal delay={220}>
              <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-x-6 gap-y-5">
                {t.about.facts.map((f) => (
                  <div key={f.v} className="border-t border-[var(--text)] pt-3">
                    <div className="font-display text-[28px] md:text-[34px] font-medium tracking-tight text-[var(--text)]">{f.k}</div>
                    <div className="mt-1 text-[11px] font-mono uppercase tracking-[0.14em] text-[var(--muted)]">{f.v}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stack({ t }) {
  const icons = ["layout-panel-top", "radio", "terminal"];
  return (
    <section id="stack" className="relative py-24 md:py-36 border-t border-[var(--border)] bg-[var(--surface-0)]">
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid lg:grid-cols-12 gap-8 mb-12 md:mb-16">
          <div className="lg:col-span-5">
            <Reveal><Eyebrow>{t.stack.eyebrow}</Eyebrow></Reveal>
            <Reveal delay={80}>
              <h2 className="mt-6 font-display font-medium tracking-[-0.025em] text-[var(--text)] text-[34px] md:text-[52px] leading-[1.02]">
                {t.stack.title}
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-6 lg:col-start-7 lg:pt-4">
            <Reveal delay={120}>
              <p className="text-[15.5px] md:text-[16.5px] text-[var(--muted)] leading-relaxed">{t.stack.sub}</p>
            </Reveal>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-px bg-[var(--border)] border border-[var(--border)]">
          {t.stack.groups.map((g, i) => (
            <Reveal key={g.title} delay={i * 100}>
              <div className="group relative bg-[var(--bg)] p-6 md:p-8 h-full hover:bg-[var(--surface-1)] transition-colors">
                <div className="flex items-start justify-between">
                  <div className="inline-flex items-center justify-center h-11 w-11 rounded-full border border-[var(--border-strong)] text-[var(--text)] group-hover:rotate-12 transition-transform">
                    <Icon name={icons[i]} size={18} />
                  </div>
                  <span className="font-mono text-[10.5px] tracking-[0.18em] uppercase text-[var(--muted-2)]">0{i + 1}</span>
                </div>
                <h3 className="mt-6 font-display text-xl md:text-2xl font-medium tracking-tight text-[var(--text)]">{g.title}</h3>
                <ul className="mt-5 flex flex-wrap gap-1.5">
                  {g.items.map((it) => (
                    <li key={it} className="border border-[var(--border)] bg-[var(--surface-1)] px-2.5 py-1 text-[12.5px] text-[var(--text-2)] font-mono">{it}</li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

// Project mockups
function MockRealtime() {
  return (
    <div className="absolute inset-0 p-5 flex flex-col gap-3" dir="ltr">
      <div className="flex items-center gap-2 text-[11px] font-mono text-[var(--muted)]">
        <span className="h-2 w-2 rounded-full bg-emerald-400 pulse-dot" />
        socket.io · live
        <span className="ms-auto text-[var(--muted-2)]">412ms</span>
      </div>
      <div className="grid grid-cols-8 gap-1 mt-1">
        {Array.from({ length: 48 }).map((_, i) => {
          const h = 10 + ((i * 17) % 32);
          return <div key={i} className="rounded-sm bg-gradient-to-t from-[var(--accent-2)]/40 to-[var(--accent-3)]/30" style={{ height: h }} />;
        })}
      </div>
      <div className="mt-auto rounded border border-[var(--border)] bg-[var(--surface-2)] p-3 font-mono text-[11px] text-[var(--muted)] leading-relaxed">
        <div><span className="text-[var(--muted-2)]">→</span> ws://api/stream <span className="text-emerald-400">200</span></div>
        <div><span className="text-[var(--muted-2)]">←</span> tick #11824 · 0.39s</div>
      </div>
    </div>
  );
}
function MockRBAC() {
  const roles = ["admin", "manager", "trainer", "trainee", "viewer"];
  return (
    <div className="absolute inset-0 p-5 flex flex-col gap-3" dir="ltr">
      <div className="flex items-center gap-2 text-[11px] font-mono text-[var(--muted)]">
        <Icon name="shield-check" size={12} />
        permissions · 5 roles
      </div>
      <div className="space-y-1.5 mt-1">
        {roles.map((r, i) => (
          <div key={r} className="flex items-center gap-2">
            <div className="w-16 text-[10.5px] font-mono text-[var(--muted-2)] truncate">{r}</div>
            <div className="flex-1 h-2 bg-[var(--surface-2)] overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[var(--accent-3)]/70 to-[var(--accent-2)]/70" style={{ width: `${20 + i * 18}%` }} />
            </div>
          </div>
        ))}
      </div>
      <div className="mt-auto rounded border border-[var(--border)] bg-[var(--surface-2)] p-3 font-mono text-[11px] text-[var(--muted)]">
        <div><span className="text-[var(--muted-2)]">if</span> user.can(<span className="text-[var(--accent-3)]">"edit"</span>)</div>
      </div>
    </div>
  );
}
function MockPerf() {
  return (
    <div className="absolute inset-0 p-5 flex flex-col gap-3" dir="ltr">
      <div className="flex items-center gap-2 text-[11px] font-mono text-[var(--muted)]"><Icon name="gauge" size={12} />lighthouse</div>
      <div className="flex items-center gap-5 mt-1">
        <div className="relative h-20 w-20">
          <svg viewBox="0 0 36 36" className="h-full w-full -rotate-90">
            <circle cx="18" cy="18" r="15.9" stroke="var(--surface-2)" strokeWidth="2.5" fill="none" />
            <circle cx="18" cy="18" r="15.9" stroke="url(#perfg)" strokeWidth="2.5" fill="none" strokeDasharray="100" strokeDashoffset="15" strokeLinecap="round" />
            <defs><linearGradient id="perfg"><stop offset="0%" stopColor="#34d399" /><stop offset="100%" stopColor="#22d3ee" /></linearGradient></defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center font-display text-xl font-semibold text-[var(--text)]">85</div>
        </div>
        <div className="text-[11px] font-mono text-[var(--muted)]">
          <div>FCP <span className="text-[var(--text-2)]">1.2s</span></div>
          <div>TBT <span className="text-[var(--text-2)]">90ms</span></div>
          <div>CLS <span className="text-[var(--text-2)]">0.02</span></div>
        </div>
      </div>
      <div className="mt-auto h-12 relative">
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 40" preserveAspectRatio="none">
          <path d="M0 30 L 40 28 L 80 22 L 120 14 L 160 9 L 200 6" stroke="url(#perfg)" strokeWidth="1.5" fill="none" />
          <path d="M0 30 L 40 28 L 80 22 L 120 14 L 160 9 L 200 6 L 200 40 L 0 40 Z" fill="url(#perfg)" opacity="0.15" />
        </svg>
      </div>
    </div>
  );
}

function Work({ t }) {
  const Mocks = [MockRealtime, MockRBAC, MockPerf];
  const accents = ["from-[var(--accent-2)]/15 via-[var(--accent-2)]/5", "from-[var(--accent-3)]/15 via-[var(--accent-3)]/5", "from-emerald-400/12 via-emerald-400/5"];
  return (
    <section id="work" className="relative py-24 md:py-36 border-t border-[var(--border)]">
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid lg:grid-cols-12 gap-8 mb-12 md:mb-16 items-end">
          <div className="lg:col-span-7">
            <Reveal><Eyebrow>{t.work.eyebrow}</Eyebrow></Reveal>
            <Reveal delay={80}>
              <h2 className="mt-6 font-display font-medium tracking-[-0.025em] text-[var(--text)] text-[34px] md:text-[52px] xl:text-[60px] leading-[1.02]">
                {t.work.title}
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-4 lg:col-start-9">
            <Reveal delay={120}>
              <p className="text-[13px] font-mono text-[var(--muted)] flex items-center gap-2"><Icon name="info" size={12} />{t.work.sub}</p>
            </Reveal>
          </div>
        </div>

        <div className="space-y-4 md:space-y-6">
          {t.work.cases.map((c, i) => {
            const Mock = Mocks[i];
            const reverse = i % 2 === 1;
            return (
              <Reveal key={c.title} delay={i * 80}>
                <article className={`group relative overflow-hidden border border-[var(--border)] bg-[var(--bg)] grid lg:grid-cols-12 hover:border-[var(--border-strong)] transition-colors`}>
                  <div className={`relative h-56 sm:h-64 lg:h-auto lg:col-span-5 ${reverse ? "lg:order-2" : ""} border-b lg:border-b-0 ${reverse ? "lg:border-s" : "lg:border-e"} border-[var(--border)] bg-gradient-to-br ${accents[i]} to-transparent`}>
                    <div className="absolute inset-0 hero-grid opacity-40" />
                    <Mock />
                  </div>
                  <div className={`p-6 md:p-10 lg:col-span-7 flex flex-col ${reverse ? "lg:order-1" : ""}`}>
                    <div className="flex items-center justify-between text-[10.5px] font-mono uppercase tracking-[0.18em] text-[var(--muted)]">
                      <span>{c.tag}</span>
                      <Icon name="arrow-up-right" size={14} className="text-[var(--muted)] group-hover:text-[var(--text)] group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all" />
                    </div>
                    <h3 className="mt-5 font-display text-2xl md:text-[34px] xl:text-[40px] font-medium tracking-[-0.02em] text-[var(--text)] leading-[1.1]">{c.title}</h3>
                    <p className="mt-4 text-[14.5px] md:text-[15.5px] text-[var(--muted)] leading-relaxed max-w-xl">{c.desc}</p>
                    <div className="mt-auto pt-7 grid grid-cols-3 gap-px bg-[var(--border)] border border-[var(--border)]">
                      {c.metrics.map((m) => (
                        <div key={m.v} className="bg-[var(--bg)] p-3 md:p-4">
                          <div className="font-display text-lg md:text-2xl font-medium tracking-tight text-[var(--text)]">{m.k}</div>
                          <div className="mt-1 text-[10.5px] font-mono uppercase tracking-[0.12em] text-[var(--muted)] truncate">{m.v}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Experience({ t }) {
  return (
    <section id="experience" className="relative py-24 md:py-36 border-t border-[var(--border)] bg-[var(--surface-0)]">
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid lg:grid-cols-12 gap-8 mb-12 md:mb-16">
          <div className="lg:col-span-5">
            <Reveal><Eyebrow>{t.experience.eyebrow}</Eyebrow></Reveal>
            <Reveal delay={80}>
              <h2 className="mt-6 font-display font-medium tracking-[-0.025em] text-[var(--text)] text-[34px] md:text-[52px] leading-[1.02]">
                {t.experience.title}
              </h2>
            </Reveal>
          </div>
        </div>

        <div className="border-t border-[var(--border)]">
          {t.experience.entries.map((e, i) => (
            <Reveal key={e.org} delay={i * 100}>
              <div className="group grid lg:grid-cols-12 gap-6 lg:gap-8 py-8 md:py-12 border-b border-[var(--border)] hover:bg-[var(--surface-1)] transition-colors px-3 md:px-6 -mx-3 md:-mx-6">
                <div className="lg:col-span-3">
                  <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">{e.time}</div>
                  <div className="mt-1 font-mono text-[11px] text-[var(--muted-2)] flex items-center gap-1.5"><Icon name="map-pin" size={11} />{e.where}</div>
                </div>
                <div className="lg:col-span-9">
                  <div className="flex items-baseline gap-3 flex-wrap">
                    <h3 className="font-display text-xl md:text-3xl font-medium tracking-[-0.02em] text-[var(--text)]">{e.org}</h3>
                    <span className="text-[var(--muted)] text-[14px] md:text-[15px]">— {e.role}</span>
                  </div>
                  <ul className="mt-5 space-y-2.5 max-w-3xl">
                    {e.points.map((p) => (
                      <li key={p} className="flex gap-3 text-[14px] md:text-[15px] text-[var(--muted)] leading-[1.65]">
                        <span className="mt-[10px] h-1 w-1 shrink-0 rounded-full bg-[var(--accent-2)]" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer({ t, lang }) {
  return (
    <footer id="contact" className="relative pt-24 md:pt-36 pb-10 border-t border-[var(--border)] overflow-hidden">
      <div className="absolute inset-0 hero-glow opacity-50 pointer-events-none" />
      <div className="relative mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-8">
            <Reveal><Eyebrow>{t.contact.eyebrow}</Eyebrow></Reveal>
            <Reveal delay={80}>
              <h2 className="mt-6 font-display font-medium tracking-[-0.03em] text-[var(--text)] text-[44px] sm:text-[64px] md:text-[88px] xl:text-[112px] leading-[0.95]">
                {t.contact.titleA}{" "}
                <span className="italic-display font-light bg-gradient-to-br from-[var(--accent-2)] to-[var(--accent-3)] bg-clip-text text-transparent">{t.contact.titleB}</span>{" "}
                {t.contact.titleC}
              </h2>
            </Reveal>
            <Reveal delay={160}>
              <p className="mt-7 max-w-lg text-[15.5px] md:text-[16.5px] text-[var(--muted)] leading-relaxed">{t.contact.sub}</p>
            </Reveal>
          </div>
          <div className="lg:col-span-4 lg:pt-2">
            <Reveal delay={200}>
              <a href={`mailto:${t.contact.links.email}`} className="block border border-[var(--border)] hover:border-[var(--text)] transition-colors p-6 group">
                <div className="text-[10.5px] font-mono uppercase tracking-[0.18em] text-[var(--muted)] mb-3">{t.contact.emailLabel}</div>
                <div className="font-display text-[20px] md:text-[22px] font-medium text-[var(--text)] flex items-center gap-2 break-all" dir="ltr">
                  {t.contact.links.email}
                  <Icon name="arrow-up-right" size={18} className="ms-auto shrink-0 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </a>
              <div className="mt-3 grid grid-cols-2 gap-3">
                <a href={`tel:${t.contact.links.phone.replace(/[^\d+]/g, "")}`} className="border border-[var(--border)] hover:border-[var(--text)] p-4 transition-colors">
                  <div className="text-[10px] font-mono uppercase tracking-[0.14em] text-[var(--muted)]">Phone</div>
                  <div className="mt-1 text-[13px] text-[var(--text)] font-mono" dir="ltr">{t.contact.links.phone}</div>
                </a>
                <a href="https://www.linkedin.com/" target="_blank" rel="noopener" className="border border-[var(--border)] hover:border-[var(--text)] p-4 transition-colors flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-mono uppercase tracking-[0.14em] text-[var(--muted)]">Social</div>
                    <div className="mt-1 text-[13px] text-[var(--text)]">LinkedIn</div>
                  </div>
                  <Icon name="linkedin" size={16} className="text-[var(--muted)]" />
                </a>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Massive name signature */}
        <div className="mt-20 md:mt-28 overflow-hidden">
          <div className="font-display font-medium tracking-[-0.04em] text-[var(--text)] leading-[0.85] text-[19vw] sig-fill" dir="ltr">
            PINI<span className="italic-display font-light text-[var(--muted-2)]">.</span>SHTEREN
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-[var(--border)] flex flex-col sm:flex-row items-start sm:items-center gap-3 justify-between text-[11px] font-mono text-[var(--muted)]">
          <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />{t.contact.footer}</div>
          <div>{lang === "he" ? "ישראל · UTC+3" : "Israel · UTC+3"}</div>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { About, Stack, Work, Experience, Footer });
